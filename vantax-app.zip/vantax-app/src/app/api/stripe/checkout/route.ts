import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

// Crea una Stripe Checkout Session para que el usuario se suscriba a un plan.
// El usuario nunca escribe su tarjeta en nuestra app: Stripe aloja la página
// de pago (cumple PCI por nosotros).
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  }

  const { planId } = await req.json().catch(() => ({ planId: null }));
  if (!planId) {
    return NextResponse.json({ error: "Falta planId." }, { status: 400 });
  }

  const plan = await prisma.plan.findUnique({ where: { id: planId } });
  if (!plan || !plan.active) {
    return NextResponse.json({ error: "Plan no disponible." }, { status: 404 });
  }
  if (!plan.stripePriceId) {
    return NextResponse.json(
      { error: "Este plan todavía no tiene un Price de Stripe asociado. Configuralo desde /admin/plans." },
      { status: 400 }
    );
  }

  const user = await prisma.user.findUnique({ where: { id: (session.user as any).id } });
  if (!user) {
    return NextResponse.json({ error: "Usuario no encontrado." }, { status: 404 });
  }

  let customerId = user.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user.email,
      metadata: { userId: user.id },
    });
    customerId = customer.id;
    await prisma.user.update({ where: { id: user.id }, data: { stripeCustomerId: customerId } });
  }

  const origin = req.headers.get("origin") ?? process.env.NEXTAUTH_URL ?? "";

  const checkoutSession = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price: plan.stripePriceId, quantity: 1 }],
    success_url: `${origin}/dashboard?checkout=success`,
    cancel_url: `${origin}/?checkout=cancelled`,
    metadata: { userId: user.id, planId: plan.id },
    subscription_data: {
      metadata: { userId: user.id, planId: plan.id },
    },
  });

  return NextResponse.json({ url: checkoutSession.url });
}
