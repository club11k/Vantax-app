import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";

// Stripe necesita el body crudo (sin parsear) para poder verificar la firma,
// así que desactivamos el body parser por defecto de Next para esta ruta.
export const runtime = "nodejs";

function addOneMonth(date: Date): Date {
  const d = new Date(date);
  d.setMonth(d.getMonth() + 1);
  return d;
}

async function syncSubscription(subscription: Stripe.Subscription) {
  const userId = subscription.metadata?.userId;
  const planId = subscription.metadata?.planId;
  if (!userId) return;

  const statusMap: Record<Stripe.Subscription.Status, "ACTIVE" | "PAST_DUE" | "CANCELED" | "TRIALING" | "NONE"> = {
    active: "ACTIVE",
    trialing: "TRIALING",
    past_due: "PAST_DUE",
    canceled: "CANCELED",
    unpaid: "PAST_DUE",
    incomplete: "NONE",
    incomplete_expired: "CANCELED",
    paused: "CANCELED",
  };

  await prisma.user.update({
    where: { id: userId },
    data: {
      stripeSubscriptionId: subscription.id,
      subscriptionStatus: statusMap[subscription.status] ?? "NONE",
      ...(planId ? { planId } : {}),
    },
  });
}

export async function POST(req: Request) {
  const sig = req.headers.get("stripe-signature");
  const rawBody = await req.text();

  if (!sig || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Falta la firma o el webhook secret." }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return NextResponse.json({ error: `Firma inválida: ${(err as Error).message}` }, { status: 400 });
  }

  switch (event.type) {
    case "checkout.session.completed": {
      const checkoutSession = event.data.object as Stripe.Checkout.Session;
      const userId = checkoutSession.metadata?.userId;
      const planId = checkoutSession.metadata?.planId;
      if (userId && checkoutSession.subscription) {
        const now = new Date();
        await prisma.user.update({
          where: { id: userId },
          data: {
            stripeSubscriptionId: checkoutSession.subscription as string,
            subscriptionStatus: "ACTIVE",
            planId: planId ?? undefined,
            analysesUsedInPeriod: 0,
            periodStart: now,
            periodEnd: addOneMonth(now),
          },
        });
      }
      break;
    }

    case "customer.subscription.updated":
    case "customer.subscription.created": {
      await syncSubscription(event.data.object as Stripe.Subscription);
      break;
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      const userId = subscription.metadata?.userId;
      if (userId) {
        await prisma.user.update({
          where: { id: userId },
          data: { subscriptionStatus: "CANCELED" },
        });
      }
      break;
    }

    case "invoice.paid": {
      // Nuevo ciclo de facturación pagado: reseteamos la cuota mensual de análisis.
      const invoice = event.data.object as Stripe.Invoice;
      const subscriptionId = invoice.subscription as string | null;
      if (subscriptionId) {
        const user = await prisma.user.findFirst({ where: { stripeSubscriptionId: subscriptionId } });
        if (user) {
          const now = new Date();
          await prisma.user.update({
            where: { id: user.id },
            data: {
              analysesUsedInPeriod: 0,
              periodStart: now,
              periodEnd: addOneMonth(now),
              subscriptionStatus: "ACTIVE",
            },
          });
        }
      }
      break;
    }

    default:
      break;
  }

  return NextResponse.json({ received: true });
}
